package com.tehtava.openshift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenshiftApplicationTests {

	@Test
	void contextLoads() {
	}

}
